

def isascii(s):
    return len(s) == len(s.encode())


