


you can download ncc v0.2.0 from https://github.com/kendryte/nncase/releases/tag/v0.2.0-beta4

and rename to `ncc_v0.2`, and the executable path is `tools/ncc/ncc_v0.2/ncc`


